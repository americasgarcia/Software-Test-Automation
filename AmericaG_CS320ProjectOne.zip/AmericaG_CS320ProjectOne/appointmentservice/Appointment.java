package appointmentservice;

import java.util.Date;

public class Appointment {
    private final String appointmentId; // not updatable
    private Date appointmentDate;
    private String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) {
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("bad id");
        }
        this.appointmentId = appointmentId;
        setAppointmentDate(appointmentDate);
        setDescription(description);
    }

    public String getAppointmentId() { return appointmentId; }
    public Date getAppointmentDate() { return appointmentDate; }
    public String getDescription() { return description; }

    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null) throw new IllegalArgumentException("bad date");
        Date now = new Date();
        if (appointmentDate.before(now)) throw new IllegalArgumentException("date in past");
        this.appointmentDate = appointmentDate;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("bad description");
        }
        this.description = description;
    }
}
