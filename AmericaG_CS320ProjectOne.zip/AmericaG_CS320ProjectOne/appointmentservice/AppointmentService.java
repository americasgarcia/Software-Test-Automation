package appointmentservice;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private final Map<String, Appointment> store = new HashMap<>();

    public boolean addAppointment(Appointment a) {
        if (a == null) throw new IllegalArgumentException("null appointment");
        String id = a.getAppointmentId();
        if (store.containsKey(id)) throw new IllegalArgumentException("duplicate id");
        store.put(id, a);
        return true;
    }

    public boolean addAppointment(String id, java.util.Date date, String desc) {
        return addAppointment(new Appointment(id, date, desc));
    }

    public boolean deleteAppointment(String id) {
        return store.remove(id) != null;
    }

    public Appointment get(String id) {
        return store.get(id);
    }
}