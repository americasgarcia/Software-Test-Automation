package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Calendar;
import java.util.Date;

public class AppointmentServiceTest {
    private Date futureDate(int days) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, days);
        return c.getTime();
    }

    @Test
    void addAndGet() {
        AppointmentService s = new AppointmentService();
        assertTrue(s.addAppointment("A1", futureDate(1), "Dentist"));
        Appointment a = s.get("A1");
        assertNotNull(a);
        assertEquals("Dentist", a.getDescription());
    }

    @Test
    void noDuplicateIds() {
        AppointmentService s = new AppointmentService();
        s.addAppointment("A1", futureDate(1), "Visit");
        assertThrows(IllegalArgumentException.class,
            () -> s.addAppointment("A1", futureDate(2), "Another"));
    }

    @Test
    void deleteWorks() {
        AppointmentService s = new AppointmentService();
        s.addAppointment("A1", futureDate(1), "Visit");
        assertTrue(s.deleteAppointment("A1"));
        assertFalse(s.deleteAppointment("A1"));
    }
}