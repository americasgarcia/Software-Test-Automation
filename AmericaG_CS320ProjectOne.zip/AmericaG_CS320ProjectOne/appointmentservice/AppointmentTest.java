package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;
import java.util.Calendar;

public class AppointmentTest {

    private Date futureDate(int days) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, days);
        return c.getTime();
    }

    @Test
    void makeValidAppointment() {
        Appointment a = new Appointment("A1", futureDate(1), "Dentist visit");
        assertEquals("A1", a.getAppointmentId());
        assertEquals("Dentist visit", a.getDescription());
        assertNotNull(a.getAppointmentDate());
    }

    @Test
    void badId() {
        assertThrows(IllegalArgumentException.class,
            () -> new Appointment(null, futureDate(1), "Desc"));
        assertThrows(IllegalArgumentException.class,
            () -> new Appointment("TOO_LONG_ID_123", futureDate(1), "Desc"));
    }

    @Test
    void badDate() {
        Date past = new Date(System.currentTimeMillis() - 24L*60*60*1000);
        assertThrows(IllegalArgumentException.class,
            () -> new Appointment("A1", null, "Desc"));
        assertThrows(IllegalArgumentException.class,
            () -> new Appointment("A1", past, "Desc"));
    }

    @Test
    void badDescription() {
        assertThrows(IllegalArgumentException.class,
            () -> new Appointment("A1", futureDate(1), null));
        String longDesc = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"; // 51
        assertThrows(IllegalArgumentException.class,
            () -> new Appointment("A1", futureDate(1), longDesc));
    }

    @Test
    void settersWork() {
        Appointment a = new Appointment("A2", futureDate(2), "Checkup");
        a.setDescription("Annual checkup");
        assertEquals("Annual checkup", a.getDescription());

        a.setAppointmentDate(futureDate(3));
        assertNotNull(a.getAppointmentDate());

        assertThrows(IllegalArgumentException.class, () -> a.setDescription(null));
        assertThrows(IllegalArgumentException.class, () -> a.setDescription("yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy"));
        Date past = new Date(System.currentTimeMillis() - 1000);
        assertThrows(IllegalArgumentException.class, () -> a.setAppointmentDate(past));
    }
}