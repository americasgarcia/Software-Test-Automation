package contactservice;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> store = new HashMap<>();

    public boolean addContact(Contact c) {
        if (c == null) throw new IllegalArgumentException("null");
        String id = c.getContactId();
        if (store.containsKey(id)) throw new IllegalArgumentException("duplicate id");
        store.put(id, c);
        return true;
    }

    public boolean addContact(String id, String first, String last, String phone, String addr) {
        return addContact(new Contact(id, first, last, phone, addr));
    }

    public boolean deleteContact(String id) {
        return store.remove(id) != null;
    }

    public boolean updateFirstName(String id, String first) {
        Contact c = store.get(id);
        if (c == null) return false;
        c.setFirstName(first);
        return true;
    }

    public boolean updateLastName(String id, String last) {
        Contact c = store.get(id);
        if (c == null) return false;
        c.setLastName(last);
        return true;
    }

    public boolean updatePhone(String id, String phone) {
        Contact c = store.get(id);
        if (c == null) return false;
        c.setPhone(phone);
        return true;
    }

    public boolean updateAddress(String id, String addr) {
        Contact c = store.get(id);
        if (c == null) return false;
        c.setAddress(addr);
        return true;
    }

    public Contact get(String id) {
        return store.get(id);
    }
}