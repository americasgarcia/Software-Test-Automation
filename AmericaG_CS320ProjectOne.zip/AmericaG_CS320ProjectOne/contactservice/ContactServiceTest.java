package contactservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    void addAndGet() {
        ContactService s = new ContactService();
        assertTrue(s.addContact("ID1","John","Doe","1234567890","123 Main St"));
        Contact c = s.get("ID1");
        assertNotNull(c);
        assertEquals("John", c.getFirstName());
    }

    @Test
    void noDuplicateIds() {
        ContactService s = new ContactService();
        s.addContact("ID1","A","B","0123456789","Addr");
        assertThrows(IllegalArgumentException.class, () ->
            s.addContact("ID1","X","Y","1112223333","Addr2"));
    }

    @Test
    void deleteWorks() {
        ContactService s = new ContactService();
        s.addContact("ID1","A","B","0123456789","Addr");
        assertTrue(s.deleteContact("ID1"));
        assertFalse(s.deleteContact("ID1"));
    }

    @Test
    void updatesWork() {
        ContactService s = new ContactService();
        s.addContact("ID1","John","Doe","1234567890","123 Main St");
        assertTrue(s.updateFirstName("ID1","Jane"));
        assertTrue(s.updateLastName("ID1","Smith"));
        assertTrue(s.updatePhone("ID1","1112223333"));
        assertTrue(s.updateAddress("ID1","456 Oak Ave"));
        Contact c = s.get("ID1");
        assertEquals("Jane", c.getFirstName());
        assertEquals("Smith", c.getLastName());
        assertEquals("1112223333", c.getPhone());
        assertEquals("456 Oak Ave", c.getAddress());
    }

    @Test
    void updateBadValuesThrow() {
        ContactService s = new ContactService();
        s.addContact("ID1","John","Doe","1234567890","123 Main St");
        assertThrows(IllegalArgumentException.class, () -> s.updatePhone("ID1","bad"));
        assertThrows(IllegalArgumentException.class, () -> s.updateFirstName("ID1",null));
    }
}
