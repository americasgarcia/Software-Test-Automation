package contactservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    void makeValidContact() {
        Contact c = new Contact("ID1","John","Doe","1234567890","123 Main St");
        assertEquals("ID1", c.getContactId());
        assertEquals("John", c.getFirstName());
        assertEquals("Doe", c.getLastName());
        assertEquals("1234567890", c.getPhone());
        assertEquals("123 Main St", c.getAddress());
    }

    @Test
    void badId() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null,"A","B","0123456789","Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("THIS_IS_TOO_LONG","A","B","0123456789","Addr"));
    }

    @Test
    void namesAndAddressRules() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("ID1",null,"B","0123456789","Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("ID1","ABCDEFGHIJK","B","0123456789","Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("ID1","A",null,"0123456789","Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("ID1","A","ABCDEFGHIJK","0123456789","Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("ID1","A","B","0123456789",null));
        assertThrows(IllegalArgumentException.class, () -> new Contact("ID1","A","B","0123456789","1234567890123456789012345678901"));
    }

    @Test
    void phoneRules() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("ID1","A","B","123","Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("ID1","A","B","12345678901","Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("ID1","A","B","12345abc90","Addr"));
    }

    @Test
    void settersWork() {
        Contact c = new Contact("ID2","A","B","0123456789","Addr");
        c.setFirstName("Jane");
        c.setLastName("Smith");
        c.setPhone("1112223333");
        c.setAddress("456 Oak Ave");
        assertEquals("Jane", c.getFirstName());
        assertEquals("Smith", c.getLastName());
        assertEquals("1112223333", c.getPhone());
        assertEquals("456 Oak Ave", c.getAddress());
    }
}