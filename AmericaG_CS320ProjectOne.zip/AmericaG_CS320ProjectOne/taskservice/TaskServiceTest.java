package taskservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    void addAndGet() {
        TaskService s = new TaskService();
        assertTrue(s.addTask("T1", "Homework", "Finish CS320 milestone"));
        Task t = s.get("T1");
        assertNotNull(t);
        assertEquals("Homework", t.getName());
    }

    @Test
    void noDuplicateIds() {
        TaskService s = new TaskService();
        s.addTask("T1", "A", "Desc");
        assertThrows(IllegalArgumentException.class,
            () -> s.addTask("T1", "B", "Another desc"));
    }

    @Test
    void deleteWorks() {
        TaskService s = new TaskService();
        s.addTask("T1", "A", "Desc");
        assertTrue(s.deleteTask("T1"));
        assertFalse(s.deleteTask("T1"));
    }

    @Test
    void updatesWork() {
        TaskService s = new TaskService();
        s.addTask("T1", "Homework", "Do work");
        assertTrue(s.updateName("T1", "Quiz"));
        assertTrue(s.updateDescription("T1", "Study for quiz"));
        Task t = s.get("T1");
        assertEquals("Quiz", t.getName());
        assertEquals("Study for quiz", t.getDescription());
    }

    @Test
    void updateBadValuesThrow() {
        TaskService s = new TaskService();
        s.addTask("T1", "Homework", "Do work");
        assertThrows(IllegalArgumentException.class,
            () -> s.updateName("T1", null));
        assertThrows(IllegalArgumentException.class,
            () -> s.updateDescription("T1",
                "This description is way too long to be valid and should fail because it breaks the 50 character rule."));
    }
}