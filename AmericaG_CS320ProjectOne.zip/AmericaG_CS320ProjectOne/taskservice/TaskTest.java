package taskservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    void makeValidTask() {
        Task t = new Task("T1", "Homework", "Finish CS320 milestone");
        assertEquals("T1", t.getTaskId());
        assertEquals("Homework", t.getName());
        assertEquals("Finish CS320 milestone", t.getDescription());
    }

    @Test
    void badId() {
        assertThrows(IllegalArgumentException.class,
            () -> new Task(null, "Name", "Desc"));
        assertThrows(IllegalArgumentException.class,
            () -> new Task("TOO_LONG_ID_123", "Name", "Desc"));
    }

    @Test
    void badNameOrDescription() {
        assertThrows(IllegalArgumentException.class,
            () -> new Task("T1", null, "Desc"));
        assertThrows(IllegalArgumentException.class,
            () -> new Task("T1", "ThisNameIsWayTooLongForTheLimit", "Desc"));
        assertThrows(IllegalArgumentException.class,
            () -> new Task("T1", "Name", null));
        assertThrows(IllegalArgumentException.class,
            () -> new Task("T1", "Name",
                "123456789012345678901234567890123456789012345678901")); // 51 chars
    }

    @Test
    void settersWork() {
        Task t = new Task("T2", "A", "Desc");
        t.setName("NewName");
        t.setDescription("New description");
        assertEquals("NewName", t.getName());
        assertEquals("New description", t.getDescription());
    }
}