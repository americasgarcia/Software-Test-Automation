package taskservice;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> store = new HashMap<>();

    public boolean addTask(Task t) {
        if (t == null) throw new IllegalArgumentException("null task");
        String id = t.getTaskId();
        if (store.containsKey(id)) {
            throw new IllegalArgumentException("duplicate id");
        }
        store.put(id, t);
        return true;
    }

    public boolean addTask(String id, String name, String desc) {
        return addTask(new Task(id, name, desc));
    }

    public boolean deleteTask(String id) {
        return store.remove(id) != null;
    }

    public boolean updateName(String id, String name) {
        Task t = store.get(id);
        if (t == null) return false;
        t.setName(name);
        return true;
    }

    public boolean updateDescription(String id, String desc) {
        Task t = store.get(id);
        if (t == null) return false;
        t.setDescription(desc);
        return true;
    }

    public Task get(String id) {
        return store.get(id);
    }
}